<div class="usuario">
    
    <h4>
        Producto: <?= $fila["Producto"]."<br>"?>
        Nombre de cliente: <?= $fila["Cliente"] ."<br>"?>
        Cantidad: <?= $fila["cantidad"]."<br>"?>
    </h4>
</div>