<option value="<?= $_GET["idCat"] ?>">
                <?= $_GET["nombreGenero"] ?>
</option> 