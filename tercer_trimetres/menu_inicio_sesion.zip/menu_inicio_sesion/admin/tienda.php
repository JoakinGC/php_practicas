<?php
    include("../includes/validarLogin.php");
    echo "<h1>Cliente</h1>";

?>